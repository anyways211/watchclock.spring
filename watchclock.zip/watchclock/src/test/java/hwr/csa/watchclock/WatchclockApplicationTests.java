package hwr.csa.watchclock;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WatchclockApplicationTests {

	@Test
	void contextLoads() {
	}

}
